Site Size
===
This repository contains the code for returning the size of the web page.
---
Installation
---
For Installing the dependency and saving the package 
`python setup.py install`
If you just want to test the package without installing
* Clone the repository `git clone https://github.com/Mianto/sitesize.git`
* Navigate to sitesize folder containing main.py
* Run main.py as `python main.py`